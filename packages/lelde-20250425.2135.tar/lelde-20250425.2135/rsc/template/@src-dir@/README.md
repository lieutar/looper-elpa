# {{name}}

{{() "{\{description-brief}\}"}}

{{() (format "{\{(description) %S}\}"
'(s-replace-regexp "\\(`[^']+\\)'" "\\1`" commentary))}}
  
## Lincense

{{() "{\{license}\}"}}

## Copyright

{{() "{\{copyright}\}"}}

