# {{name}}

{{() "{\{brief}\}"}}

{{() (format "{\{(commentary) %S}\}"
'(s-replace-regexp "\\(`[^']+\\)'" "\\1`" commentary))}}
  
## License

{{() "{\{license}\}"}}

## Copyright

{{() "{\{copyright}\}"}}

