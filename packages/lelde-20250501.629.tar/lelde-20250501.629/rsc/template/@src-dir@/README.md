# {{name}}

{{() "{\{description-brief}\}"}}

{{() (format "{\{(commentary) %S}\}"
'(s-replace-regexp "\\(`[^']+\\)'" "\\1`" commentary))}}
  
## Lincense

{{() "{\{license}\}"}}

## Copyright

{{() "{\{copyright}\}"}}

